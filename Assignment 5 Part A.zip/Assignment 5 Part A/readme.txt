Grid-Used grid to set columns and rows
Tables-Used tables for contact section
Images-Used Images to display image of about section
Buttons- Used Buttons and Button Groups to display buttons.
Glyphicons -Used it in Contact section
DropDowns- used dropdown to show skills and Nav section
ScrollSpy- Used scrollspy to display navbar
Filters- Used filters to search skills
Modal -Used modal to display resume and github
Carousel- Used carousel to display achievements
Cardlayout- used cards to display projects.
Media Object- used Media object to display education and exp.